package com.example.qq.discuss;

public class NowMsg {
    private static String mcontent;

    public NowMsg(String content){
        mcontent = content;
    }

    public String getMcontent() {
        return mcontent;
    }

}
