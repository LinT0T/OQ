package com.example.qq.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.qq.DiscussActivity;
import com.example.qq.MainViewActivity;
import com.example.qq.MyMainAdapter;
import com.example.qq.R;

import java.util.ArrayList;
import java.util.List;

public class ChatFragment extends Fragment {

    private RecyclerView mrv_main;
    private Context mContext;
    private List<String> mNowMsg = new ArrayList<>();
    private final MyMainAdapter adapter = new MyMainAdapter(mContext, mNowMsg, new MyMainAdapter.ItemOnClickListener() {
        @Override
        public void onClick(int pos) {
            Intent intent = new Intent(mContext, DiscussActivity.class);
            startActivityForResult(intent, 1);
        }
    });


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chat, container, false);

        mrv_main = view.findViewById(R.id.rv_main);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mrv_main.setLayoutManager(linearLayoutManager);
        mrv_main.setAdapter(adapter);


        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;
//        if(mNowMsg.size() > 0)
//        Log.d("onAttach____ ",mNowMsg.get(mNowMsg.size() - 1));
//        else
//            Log.d( "mnowmsg是空的 ","attach__________");
    }

//    public void setmNowMsg(List<String> mNowMsg) {
//        this.mNowMsg = mNowMsg;
//        if(mNowMsg.size() > 0)
//            Log.d("set____ ",mNowMsg.get(mNowMsg.size() - 1));
//        else
//            Log.d( "mnowmsg是空的 ","set__________");
//    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == 3) {
            String result = data.getStringExtra("result");
            mNowMsg.add(result);
            adapter.notifyDataSetChanged();
            adapter.notifyItemChanged(0);
        }
    }
}