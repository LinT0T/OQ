package com.example.qq;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.example.qq.discuss.Msg;
import com.example.qq.discuss.MsgAdapter;

import java.util.ArrayList;
import java.util.List;

import com.example.qq.tuling.Input;

public class DiscussActivity extends AppCompatActivity {

    private Button mbtn_back;
    private RecyclerView mrv_discuss;
    private List<Msg> msgList = new ArrayList<>();
    private EditText medt_discuss;
    private String sendText = "";
    private Msg msg2;

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode== KeyEvent.KEYCODE_BACK){
            Intent intent = new Intent();
            if (!sendText.equals("")) {
                intent.putExtra("result",msg2.getMcontent());
                setResult(3,intent);
            }
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
             setContentView(R.layout.activity_discuss);

        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                .detectDiskReads().detectDiskWrites().detectNetwork()
                .penaltyLog().build());
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
                .detectLeakedSqlLiteObjects().detectLeakedClosableObjects()
                .penaltyLog().penaltyDeath().build());

        medt_discuss = findViewById(R.id.et_discuss);
        mbtn_back = findViewById(R.id.btn_back);

        Button mbtn_takephoto = findViewById(R.id.btn_takephoto);
        mbtn_takephoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
                startActivity(intent);
            }
        });
        initMsgs();
        mrv_discuss = findViewById(R.id.rv_discuss);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mrv_discuss.setLayoutManager(linearLayoutManager);
        final MsgAdapter adapter =new MsgAdapter(msgList);
        mrv_discuss.setAdapter(adapter);
        Button button1 = findViewById(R.id.bt_send);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendText = medt_discuss.getText().toString();
                if (!"".equals(sendText)){
                    Msg msg = new Msg(sendText,Msg.TYPE_ME);
                    msgList.add(msg);
                    adapter.notifyItemInserted(msgList.size() - 1);
                    mrv_discuss.scrollToPosition(msgList.size() - 1);
                    medt_discuss.setText("");
                    msg2 = new Msg(Input.getString(sendText),Msg.TYPE_OTHER);
                    msgList.add(msg2);
                    adapter.notifyItemInserted(msgList.size() - 1);
                    mrv_discuss.scrollToPosition(msgList.size() - 1);
                    medt_discuss.setText("");
                }
            }
        });

        mbtn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  moveTaskToBack(true);
                Intent intent = new Intent();
                if (!sendText.equals("")) {
                intent.putExtra("result",msg2.getMcontent());
                setResult(3,intent);
                }
                finish();
            }
        });
    }

    private void initMsgs() {
        Msg msg1 = new Msg("我们已经是好友了，快开始聊天吧！",Msg.TYPE_OTHER);
        msgList.add(msg1);
    }
}
