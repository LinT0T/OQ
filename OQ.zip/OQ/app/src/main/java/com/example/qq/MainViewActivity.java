package com.example.qq;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import com.example.qq.fragment.ChatFragment;
import com.example.qq.fragment.FriendsFragment;
import com.example.qq.fragment.QzoneFragment;

public class MainViewActivity extends AppCompatActivity {

    private TextView mtv_title;
    private Button mbtn_chat;
    private Button mbtn_Qzone;
    private Button mbtn_friends;
    private Button mbtn_camera;
    private List<String> nowMsg= new ArrayList<>();
    private ChatFragment chatFragment;
    private FriendsFragment friendsFragment;
    private QzoneFragment qzoneFragment;
    private FragmentManager fragmentManager;
    private MyImageView myImageView;

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(false);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_view);
        mtv_title = findViewById(R.id.tv_title);
        mbtn_camera = findViewById(R.id.btn_camera);
        mbtn_friends = findViewById(R.id.btn_friends);
        mbtn_chat = findViewById(R.id.btn_chat);
        mbtn_Qzone = findViewById(R.id.btn_Qzone);
        myImageView = findViewById(R.id.head);
        chatFragment = new ChatFragment();
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().add(R.id.fl_main,chatFragment).commitAllowingStateLoss();
        setListenrs();


    }

    private void setListenrs(){
        OnClick onClick = new OnClick();
        mbtn_camera.setOnClickListener(onClick);
        mbtn_friends.setOnClickListener(onClick);
        mbtn_Qzone.setOnClickListener(onClick);
        mbtn_chat.setOnClickListener(onClick);
        myImageView.setOnClickListener(onClick);
    }

    private class OnClick implements View.OnClickListener{


        @Override
        public void onClick(View v) {
            Intent intent = null;
            switch (v.getId()){
                case R.id.btn_camera:
                    intent = new Intent("android.media.action.IMAGE_CAPTURE");
                    startActivity(intent);
                    break;
                case R.id.btn_friends:
                    mtv_title.setText("联系人");
                    if (friendsFragment == null){
                        friendsFragment = new FriendsFragment();
                        fragmentManager.beginTransaction().replace(R.id.fl_main,friendsFragment).commitAllowingStateLoss();
                    }
                    else fragmentManager.beginTransaction().replace(R.id.fl_main,friendsFragment).commitAllowingStateLoss();
                    break;
                case R.id.btn_chat:
                    mtv_title.setText("消息");
                    if (chatFragment == null){
                        chatFragment = new ChatFragment();
                        fragmentManager.beginTransaction().replace(R.id.fl_main,chatFragment).commitAllowingStateLoss();
                    }
                    else fragmentManager.beginTransaction().replace(R.id.fl_main,chatFragment).commitAllowingStateLoss();
                    break;

                case R.id.btn_Qzone:
                    mtv_title.setText("动态");
                    if (qzoneFragment == null){
                        qzoneFragment = new QzoneFragment();
                        fragmentManager.beginTransaction().replace(R.id.fl_main,qzoneFragment).commitAllowingStateLoss();
                    }
                    else fragmentManager.beginTransaction().replace(R.id.fl_main,qzoneFragment).commitAllowingStateLoss();
                    break;

                case R.id.head:
                    Intent i = new Intent(MainViewActivity.this,MenuActivity.class);
                    startActivity(i);
                    break;
            }

        }
    }
}
